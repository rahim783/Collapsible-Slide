package com.example.collapse_slide_bar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
